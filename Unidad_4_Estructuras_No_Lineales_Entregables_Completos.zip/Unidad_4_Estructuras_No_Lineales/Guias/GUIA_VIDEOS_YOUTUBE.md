# Guiones para los tres videos públicos de la Unidad 4

Usa el **mismo canal público** de YouTube para las tres tareas. Antes de empezar abre OBS Studio o un grabador equivalente; activa captura completa de pantalla, micrófono y **cámara web en la esquina inferior derecha**, suficientemente visible para identificar que la explicación se realiza frente a cámara. Usa resolución legible (recomendado 1080p), revisa que no aparezcan notificaciones o contraseñas y comprueba el audio.

## Video 4.1 — Árboles y grafos (5–7 minutos)
1. Presenta asignatura, Unidad 4, tarea y objetivo.
2. Abre el PDF en la parte del organizador de árboles. Señala raíz, hoja, nivel, profundidad, altura y arista. Muestra clasificación binario, ABB, AVL, montículo, B/B+ y usos.
3. Abre el organizador de grafos: explica V y E; dirigido/no dirigido; ponderado; DAG.
4. Explica el ejemplo de la matriz 4×4 y la lista de adyacencia; distingue infinito de peso cero.
5. Compara memoria O(V²) y O(V+E), y comenta en qué casos usarías cada representación.
6. Concluye con aplicaciones reales de índices, jerarquías y rutas.

## Video 4.2 — ABB dinámico (6–9 minutos)
1. Abre Visual Studio y enseña `NodoABB.cs` y `ArbolBinarioBusqueda.cs`.
2. Explica por qué los hijos son referencias dinámicas y qué sucede al insertar una clave repetida.
3. Abre el diagrama del ABB de 8 nodos y predice el inorden.
4. Ejecuta `Tarea_4_2_ABB` y muestra preorden, inorden y postorden. Explica cuándo se visita la raíz en cada uno.
5. Muestra `Buscar(65)` y `Buscar(99)`.
6. Muestra la eliminación de hoja (20), un hijo (60), dos hijos (70) y raíz (50); explica sucesor inorden.
7. Ejecuta `Pruebas` y enseña el total de verificaciones y ausencia de errores. Cierra con O(h) y la limitación de balanceo.

## Video 4.3 — Grafo y Dijkstra (6–9 minutos)
1. Presenta el problema de rutas ficticias entre bodega y cliente, con pesos en minutos.
2. Abre `Grafo_Rutas_Dijkstra.drawio` o su PDF y muestra el sentido de las flechas y los 13 arcos.
3. Enseña en Visual Studio `GrafoPonderado.CasoDistribucion` y la representación `List<Arista>[]`.
4. Ejecuta `Tarea_4_3_Rutas` y muestra matriz de adyacencia y lista de adyacencia; señala `∞` como ausencia de enlace.
5. Recorre la traza: el origen fija costo 0; Centro=4; Norte baja a 6; Este baja a 9; Parque baja a 13; Cliente baja a 16.
6. Destaca la ruta óptima Bodega → Centro → Norte → Este → Parque → Cliente = 16 minutos; explica la reconstrucción por predecesores.
7. Ejecuta `Pruebas`, muestra casos de arista negativa y destino inalcanzable y resume por qué Dijkstra no admite pesos negativos.

## Evidencias de publicación

Tras publicar, pega los enlaces reales (no inventados) en Teams:
- [ ] Video 4.1 URL pública
- [ ] Video 4.2 URL pública
- [ ] Video 4.3 URL pública
- [ ] Mismo canal en las tres URL
- [ ] Cámara inferior derecha y pantalla legible
- [ ] Enlace público de GitHub con código y diagramas
