using EstructurasNoLineales.Core.Arboles;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.WriteLine("TAREA 4.2 - ÁRBOL BINARIO DE BÚSQUEDA DINÁMICO");
var arbol = new ArbolBinarioBusqueda();
foreach (int valor in new[] { 50, 30, 70, 20, 40, 60, 80, 65 })
    Console.WriteLine($"Insertar {valor}: {arbol.Insertar(valor)}");
Mostrar();
Console.WriteLine($"Buscar 65: {arbol.Buscar(65)} | Buscar 99: {arbol.Buscar(99)}");
Console.WriteLine($"Insertar duplicado 50: {arbol.Insertar(50)} (esperado False)");
foreach (int valor in new[] { 20, 60, 70, 50 })
{
    Console.WriteLine($"Eliminar {valor}: {arbol.Eliminar(valor)}");
    Mostrar();
}
void Mostrar()
{
    Console.WriteLine("Preorden:  " + string.Join(", ", arbol.Preorden()));
    Console.WriteLine("Inorden:   " + string.Join(", ", arbol.Inorden()));
    Console.WriteLine("Postorden: " + string.Join(", ", arbol.Postorden()));
    Console.WriteLine($"Cantidad: {arbol.Cantidad}, altura(aristas): {arbol.AlturaEnAristas()}, " +
                      $"invariante válida: {arbol.ValidarInvariante()}");
}
