using EstructurasNoLineales.Core.Arboles;
using EstructurasNoLineales.Core.Grafos;

int ok = 0, fail = 0;
void Verificar(string nombre, bool condicion)
{
    if (condicion) { ok++; Console.WriteLine("OK   " + nombre); }
    else { fail++; Console.WriteLine("FAIL " + nombre); }
}
void EsIgual(string nombre, IReadOnlyList<int> real, params int[] esperado) =>
    Verificar(nombre, real.SequenceEqual(esperado));
void Falla<T>(string nombre, Action act) where T : Exception
{
    try { act(); Verificar(nombre, false); }
    catch (T) { Verificar(nombre, true); }
}

var a = new ArbolBinarioBusqueda();
Verificar("ABB vacío", a.EstaVacio && a.Cantidad == 0);
Verificar("ABB búsqueda en vacío", !a.Buscar(2));
Verificar("ABB borrar en vacío", !a.Eliminar(2));
Verificar("ABB recorridos vacíos", a.Inorden().Count == 0 && a.Preorden().Count == 0 && a.Postorden().Count == 0);
Verificar("ABB altura vacío", a.AlturaEnAristas() == -1);
foreach (int v in new[] { 50, 30, 70, 20, 40, 60, 80, 65 })
    Verificar("Insertar " + v, a.Insertar(v));
Verificar("ABB cantidad inicial", a.Cantidad == 8);
Verificar("ABB duplicados rechazados", !a.Insertar(50) && a.Cantidad == 8);
Verificar("ABB buscar existente", a.Buscar(65));
Verificar("ABB buscar inexistente", !a.Buscar(99));
EsIgual("Inorden inicial", a.Inorden(), 20,30,40,50,60,65,70,80);
EsIgual("Preorden inicial", a.Preorden(), 50,30,20,40,70,60,65,80);
EsIgual("Postorden inicial", a.Postorden(), 20,40,30,65,60,80,70,50);
Verificar("Altura inicial", a.AlturaEnAristas() == 3);
Verificar("Invariante inicial", a.ValidarInvariante());
Verificar("Borrar hoja 20", a.Eliminar(20) && !a.Buscar(20) && a.ValidarInvariante());
EsIgual("Tras borrar hoja", a.Inorden(), 30,40,50,60,65,70,80);
Verificar("Borrar nodo un hijo 60", a.Eliminar(60) && a.Buscar(65) && a.ValidarInvariante());
EsIgual("Tras borrar un hijo", a.Inorden(), 30,40,50,65,70,80);
Verificar("Borrar nodo dos hijos 70", a.Eliminar(70) && a.ValidarInvariante());
EsIgual("Tras borrar dos hijos", a.Inorden(), 30,40,50,65,80);
Verificar("Borrar raíz 50", a.Eliminar(50) && a.ValidarInvariante());
EsIgual("Tras borrar raíz", a.Inorden(), 30,40,65,80);
Verificar("No borrar inexistente", !a.Eliminar(999) && a.Cantidad == 4);
var solo = new ArbolBinarioBusqueda();
Verificar("Único insertar", solo.Insertar(-4));
Verificar("Único eliminar", solo.Eliminar(-4) && solo.EstaVacio && solo.Cantidad == 0);
var extremos = new ArbolBinarioBusqueda();
extremos.Insertar(int.MinValue); extremos.Insertar(int.MaxValue);
Verificar("ABB extremos enteros", extremos.ValidarInvariante() && extremos.Buscar(int.MaxValue));

var g = GrafoPonderado.CasoDistribucion();
Verificar("Grafo tiene siete vértices", g.NumeroVertices == 7);
var m = g.MatrizAdyacencia();
Verificar("Matriz origen->Centro", m[g.IndiceDe("Bodega"),g.IndiceDe("Centro")] == 4);
Verificar("Matriz arco inexistente", m[g.IndiceDe("Cliente"),g.IndiceDe("Bodega")] is null);
Verificar("Matriz diagonal cero", m[g.IndiceDe("Norte"),g.IndiceDe("Norte")] == 0);
Verificar("Lista adyacencia Bodega", g.Vecinos(g.IndiceDe("Bodega")).Count == 3);
Falla<ArgumentOutOfRangeException>("Negativos rechazados", () => g.AgregarArista("Bodega", "Cliente", -1));
Falla<InvalidOperationException>("Arco duplicado rechazado", () => g.AgregarArista("Bodega", "Centro", 4));
Falla<ArgumentException>("Vértice inexistente rechazado", () => g.IndiceDe("Error"));
var r = Dijkstra.Resolver(g, "Bodega");
Verificar("Costo óptimo 16", r.DistanciaHasta("Cliente") == 16);
Verificar("Camino óptimo", r.CaminoHasta("Cliente").SequenceEqual(
    new[] {"Bodega", "Centro", "Norte", "Este", "Parque", "Cliente"}));
Verificar("Distancia a origen 0", r.DistanciaHasta("Bodega") == 0);
Verificar("Distancia a Norte 6", r.DistanciaHasta("Norte") == 6);
Verificar("Traza 7 pasos", r.Pasos.Count == 7);
Verificar("Primera relajación", r.Pasos[0].Distancias[g.IndiceDe("Centro")] == 4);
Verificar("Último fijado Cliente", r.Pasos[^1].VerticeFijado == "Cliente");
var desconectado = new GrafoPonderado("A", "B", "C");
desconectado.AgregarArista("A", "B", 1);
var rd = Dijkstra.Resolver(desconectado, "A");
Verificar("Inalcanzable nulo", rd.DistanciaHasta("C") is null);
Verificar("Inalcanzable sin ruta", rd.CaminoHasta("C").Count == 0);
Verificar("Un paso por nodo alcanzable", rd.Pasos.Count == 2);
var cero = new GrafoPonderado("A", "B");
cero.AgregarArista("A", "B", 0);
Verificar("Arista de peso cero", Dijkstra.Resolver(cero, "A").DistanciaHasta("B") == 0);
Falla<ArgumentException>("Vértice repetido", () => new GrafoPonderado("A", "a"));
Falla<ArgumentException>("Sin vértices", () => new GrafoPonderado());

Console.WriteLine($"
TOTAL: {ok} correctas; {fail} fallidas");
Environment.ExitCode = fail == 0 ? 0 : 1;
