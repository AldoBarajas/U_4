# Capturas reales por producir en la computadora del alumno

1. Ejecutar `dotnet --version` y capturar el SDK disponible.
2. Ejecutar `dotnet build Codigo/Unidad_4_Estructuras_No_Lineales.sln` y capturar la línea final de compilación (sin errores).
3. Ejecutar `dotnet run --project Codigo/Tarea_4_2_ABB` y capturar la salida con los tres recorridos y las operaciones de eliminación.
4. Ejecutar `dotnet run --project Codigo/Tarea_4_3_Rutas` y capturar matriz, lista, traza y ruta óptima.
5. Ejecutar `dotnet run --project Codigo/Pruebas`, capturar resultado real del banco de pruebas y guardar la consola como texto.
6. Crear un repositorio GitHub público, subir documentos y fuente; capturar la página del repositorio.
7. Publicar los tres videos en el mismo canal de YouTube; guardar los enlaces públicos.

**Importante:** el archivo de verificación Python independiente permite contrastar resultados matemáticos, pero NO reemplaza evidencias de ejecución real de los programas C#.
