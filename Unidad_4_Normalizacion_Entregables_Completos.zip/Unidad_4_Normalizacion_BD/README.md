# Unidad 4 — Normalización de bases de datos

**Institución:** Instituto Tecnológico Superior de Monclova (TecNM)  
**Asignatura:** Fundamentos de Bases de Datos  
**Alumno:** Aldo Alberto Barajas Ancira · **Número de control:** I24050397  
**Docente:** Rubén Riojas · **Fecha:** 9 de noviembre de 2026  
**Caso:** Biblioteca escolar académica, continuidad de las Unidades 2 y 3 (no es el proyecto integrador de ferretería).

## Qué entregar en Teams

### Tarea 4.1 — Fundamentos y mapa conceptual

- `Tarea_4_1/Tarea_4_1_Mapa_Conceptual_y_Fundamentos.pdf`: reporte formal (5 páginas); la última página es el mapa conceptual vectorial A3.
- `Diagramas_Editables/Mapa_Conceptual_Formas_Normales.drawio`: fuente editable en [diagrams.net](https://app.diagrams.net/).
- `Diagramas_Exportados/Mapa_Conceptual_Formas_Normales.pdf`, `.png` y `.svg`: recursos visuales de alta calidad.
- Video público de YouTube pendiente: guion en `Guias/GUIA_VIDEOS_GITHUB_Y_EVIDENCIAS.md`.

### Tarea 4.2 — Normalización paso a paso

- `Tarea_4_2/Tarea_4_2_Normalizacion_Paso_a_Paso.pdf`: reporte (7 páginas) con demostración 0FN→1FN→2FN→3FN/FNBC, 4FN/5FN y análisis de integridad; última página con diagrama A3.
- `SQL/normalized_schema.sql`: DDL para PostgreSQL **14+**, pensado para una BD **vacía**. Se conserva la biblioteca de la Unidad 3.
- `SQL/datos_demostracion.sql`: datos ficticios para capturas de prueba.
- `SQL/verificacion_normalizacion.sql`: introspección de tablas, columnas, FK y triggers.
- `SQL/pruebas_restricciones.sql`: casos negativos que deben generar NOTICE en PostgreSQL.
- `SQL/comparacion_unidad3_unidad4.md`: justificación técnica de cambios.
- `Diagramas_Editables/Proceso_Normalizacion_Paso_a_Paso.drawio` y exportaciones PNG/SVG/PDF.
- Video público de YouTube pendiente.

## ¿Qué cambió respecto de la Unidad 3?

El archivo `Referencia_U3/schema_unidad3_referencia.sql` conserva una **copia documental** del DDL anterior (no modificar/ejecutar sobre la misma BD). El nuevo DDL mantiene las 12 tablas y 11 FK, pero elimina dos columnas de valor constante: `estudiante.tipo_persona` y `docente.tipo_persona`. Por tanto, pasa de **42 a 40 columnas**, sin eliminar datos conceptuales; `persona.tipo_persona` sigue determinando el subtipo. Nuevos triggers diferibles comprueban que la especialización total/disjunta quede satisfecha al `COMMIT`.

No se cambian los nombres de entidades ni las relaciones del proyecto. Se mantienen la separación de atributos multivalorados y las vistas para datos derivados.

## Cómo ejecutar en PostgreSQL 14+

1. Instalar PostgreSQL y pgAdmin (o utilizar psql).
2. Crear una BD **nueva y vacía** llamada `biblioteca_unidad4`. **No** ejecutar `normalized_schema.sql` sobre la base de la Unidad 3.
3. Desde la carpeta raíz del repositorio, ejecutar los archivos por separado, en este orden:

```sh
psql -X -v ON_ERROR_STOP=1 -d biblioteca_unidad4 -f SQL/normalized_schema.sql
psql -X -v ON_ERROR_STOP=1 -d biblioteca_unidad4 -f SQL/verificacion_normalizacion.sql
psql -X -v ON_ERROR_STOP=1 -d biblioteca_unidad4 -f SQL/datos_demostracion.sql
psql -X -v ON_ERROR_STOP=1 -d biblioteca_unidad4 -f SQL/pruebas_restricciones.sql
```

**Resultados esperados para comprobar en TU equipo:** 12 tablas, 40 columnas, 11 claves foráneas; especialización consistente en personas 101 y 102; 2 autores y 2 colecciones del libro; los errores deliberados se capturan como `NOTICE: OK`.

**Importante:** estos son resultados **esperados**, no evidencias que ya se hayan obtenido en PostgreSQL. Captura la ventana de pgAdmin/psql y comprueba tú mismo esos valores.

## Verificación disponible en la generación

- `Validacion/comprobar_estructura.py`: verificación estática de esquema, FK, columnas respecto del SQL original, formato de diagramas `.drawio` y existencia de PDF. Requiere Python 3 y `pypdf` para contar páginas.
- `Validacion/reporte_validacion_estatica.json`: salida registrada de esa prueba.
- **No se ejecutó PostgreSQL en el entorno de creación**; los tests SQL están listos pero pendientes de ejecución real.

## Enlaces pendientes

- GitHub: publicar este paquete en un **repositorio público** de tu cuenta.
- YouTube: grabar **dos** videos públicos **en el mismo canal** con pantalla compartida y cámara web visible en la **esquina inferior derecha**.
- Teams: enviar el PDF correspondiente, el enlace del repositorio y el enlace del video de cada tarea.

Revisa `Guias/GUIA_VIDEOS_GITHUB_Y_EVIDENCIAS.md` para una lista de capturas y guiones detallados.
