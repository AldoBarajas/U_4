"""Validación ESTÁTICA; NO sustituye ejecución en PostgreSQL."""
from pathlib import Path
import re, json, sys
BASE=Path(__file__).resolve().parents[1]
ORIGINAL=BASE/'Referencia_U3/schema_unidad3_referencia.sql'
TARGET=BASE/'SQL/normalized_schema.sql'
if not ORIGINAL.exists():
    print('ATENCIÓN: original U3 no está montado; no es posible comparar archivos fuente.')
    sys.exit(2)
source=ORIGINAL.read_text()
target=TARGET.read_text()
def tables(sql):
    blocks=re.findall(r'CREATE TABLE (\w+) \(\n(.*?)\n\);',sql,re.S)
    return {name:re.findall(r'^    ([a-z][a-z0-9_]+)\s+(?:BIGINT|VARCHAR|SMALLINT|DATE|TEXT)\b',body,re.M) for name,body in blocks}
A=tables(source);B=tables(target)
assert len(A)==12 and len(B)==12
assert set(A)==set(B)
assert sum(len(cols) for cols in A.values())==42
assert sum(len(cols) for cols in B.values())==40
for tab in B:
    removed=set(A[tab])-set(B[tab]);added=set(B[tab])-set(A[tab])
    assert added==set(), (tab,added)
    assert removed==({'tipo_persona'} if tab in ('estudiante','docente') else set()),(tab,removed)
assert source.count('FOREIGN KEY ')==11
assert target.count('FOREIGN KEY ')==11
assert target.count('CREATE CONSTRAINT TRIGGER ')==5
assert target.count('CREATE VIEW ')==3
for expected in ['persona_telefono','libro_autor','libro_coleccion','ux_prestamo_ejemplar_activo','fn_validar_subtipo','ON DELETE RESTRICT','DEFERRABLE INITIALLY DEFERRED','CHECK','NOT NULL']:
    assert expected in target, expected
assert 'DROP TABLE' not in target.upper()
for p in [BASE/'SQL/datos_demostracion.sql',BASE/'SQL/verificacion_normalizacion.sql',BASE/'SQL/pruebas_restricciones.sql']:
 assert p.exists() and p.stat().st_size>250,p
from xml.etree import ElementTree as ET
for p in (BASE/'Diagramas_Editables').glob('*.drawio'):
    x=ET.parse(p)
    assert x.getroot().tag=='mxfile' and len(x.findall('.//mxCell'))>=6
from pypdf import PdfReader
pdfs=[BASE/'Tarea_4_1/Tarea_4_1_Mapa_Conceptual_y_Fundamentos.pdf',BASE/'Tarea_4_2/Tarea_4_2_Normalizacion_Paso_a_Paso.pdf']
for p in pdfs: assert len(PdfReader(p).pages)>=4
res={'estado':'APROBADO - VERIFICACIÓN ESTÁTICA','tablas_unidad_3':len(A),'tablas_unidad_4':len(B),'columnas_unidad_3':42,'columnas_unidad_4':40,'fk':11,'vistas':3,'triggers_restriccion':5,'pdf_paginas':{p.name:len(PdfReader(p).pages) for p in pdfs},'NOTA':'Sin comprobación de ejecución en PostgreSQL por falta de servidor en este entorno.'}
(BASE/'Validacion/reporte_validacion_estatica.json').write_text(json.dumps(res,indent=2,ensure_ascii=False))
print(json.dumps(res,indent=2,ensure_ascii=False))
