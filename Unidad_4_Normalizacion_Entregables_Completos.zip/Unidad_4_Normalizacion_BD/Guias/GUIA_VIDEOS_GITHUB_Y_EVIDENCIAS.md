# Guía para GitHub, evidencias y dos videos de YouTube

**Unidad 4 · Fundamentos de Bases de Datos · Docente Rubén Riojas**  
**Alumno:** Aldo Alberto Barajas Ancira, I24050397.

## 1. Publicar el repositorio en GitHub

1. Descarga y extrae el archivo ZIP.
2. Entra a GitHub y crea un repositorio público, por ejemplo `Unidad-4-Normalizacion-Biblioteca` (nombre sugerido, NO es un enlace creado).
3. Sube el directorio completo `Unidad_4_Normalizacion_BD`, excepto la carpeta temporal `Validacion/` si prefieres no mostrar archivos de verificación. Conserva `README.md` en la raíz.
4. Revisa en GitHub que `SQL/normalized_schema.sql`, los dos PDF, los `.drawio` y las imágenes tengan vista/descarga funcional.
5. Copia la URL **real** del repositorio y pégala en Teams. No uses direcciones de ejemplo.

## 2. Video público de la Tarea 4.1 (guion de 4–6 minutos)

**Preparación:** abre el PDF 4.1 y el mapa en diagrams.net. Usa OBS Studio, Clipchamp u otro capturador; incluye una imagen de webcam visible en la **esquina inferior derecha** durante todo el video. Graba en 1080p, habla sin cubrir los cuadros y súbelo **públicamente** en el mismo canal que usas para otras unidades.

**Guion propuesto:**

- **0:00–0:35 — Presentación.** “Explicaré cómo las dependencias y la normalización reducen errores en una base de biblioteca escolar.”
- **0:35–1:35 — Anomalías.** Describe inserción, actualización y borrado, con el caso del título del libro repetido en cada préstamo.
- **1:35–2:15 — Dependencias funcionales.** Explica X→Y, parcial y transitiva: ISBN→título; préstamo→ejemplar→libro.
- **2:15–3:00 — 1FN y 2FN.** Explica por qué no guardas teléfonos en una sola celda y por qué `LIBRO_AUTOR` tiene clave compuesta.
- **3:00–4:15 — 3FN y FNBC.** Enseña el criterio formal de 3FN y el requisito de superclave en FNBC. Aclara por qué el tipo constante del subtipo es redundante.
- **4:15–5:10 — 4FN y 5FN.** Muestra autores y colecciones independientes, y por qué 5FN depende de las reglas de reunión.
- **5:10–5:40 — Conclusión.** Normalizar reduce inconsistencias, pero exige buenas consultas, índices y reglas de integridad.

**Pantallas mínimas:** portada, mapa completo (zoom suficiente), ejemplos de dependencias y tabla comparativa.

## 3. Video público de la Tarea 4.2 (guion de 5–7 minutos)

**Preparación:** abre PDF 4.2, diagrama del proceso, `normalized_schema.sql` y PostgreSQL/pgAdmin. Si todavía no ejecutaste SQL, NO presentes capturas como si ya hubieras obtenido resultados.

- **0:00–0:45 — Caso.** Biblioteca escolar; continuidad del modelo de las Unidades 2 y 3.
- **0:45–1:40 — 0FN.** Muestra una ficha con múltiples teléfonos y autores en listas, y las tres anomalías.
- **1:40–2:20 — 1FN.** Separa cada conjunto en filas atómicas, por ejemplo `persona_telefono`.
- **2:20–3:10 — 2FN.** En `(isbn, id_autor)` demuestra las dependencias parciales, luego crea LIBRO, AUTOR y LIBRO_AUTOR.
- **3:10–4:00 — 3FN.** Muestra préstamo→ejemplar→libro y cómo PRESTAMO solo conserva referencias. Explica la corrección de dos constantes en los subtipos.
- **4:00–4:45 — FNBC/4FN/5FN.** Explica claves determinantes, conjuntos multivaluados independientes y prudencia con dependencias de reunión.
- **4:45–6:15 — Prueba real.** En pgAdmin ejecuta `normalized_schema.sql` en BD vacía; abre `verificacion_normalizacion.sql` y muestra **12 tablas, 40 columnas, 11 FK**; carga los datos demo y corre las pruebas negativas. Muestra el mensaje real, no una simulación.
- **6:15–6:45 — Cierre.** Justifica por qué hay menos redundancia sin perder registros históricos.

**Capturas recomendadas (tomadas desde TU SGBD):**

- [ ] Nombre de la BD nueva `biblioteca_unidad4` antes de ejecutar.
- [ ] SQL ejecutado sin errores reales en pgAdmin.
- [ ] Inventario de 12 tablas en el esquema `biblioteca`.
- [ ] Consulta mostrando 40 columnas totales.
- [ ] Consulta mostrando 11 FK.
- [ ] Vista de `estudiante` y `docente` sin el atributo constante `tipo_persona`.
- [ ] Consultas de libros y relaciones multivaloradas.
- [ ] `NOTICE: OK` de los tres casos negativos en `pruebas_restricciones.sql`.
- [ ] ERD físico **generado desde el SGBD** (no confundirlo con el diagrama conceptual adjunto).
- [ ] Webcam en esquina inferior derecha.

## 4. Prueba manual opcional de especialización

En la BD de pruebas, el siguiente bloque, ejecutado **por separado**, debe fallar al hacer `COMMIT` porque la persona no tiene su subtipo. Si usas pgAdmin con transacción manual, tras el error ejecuta `ROLLBACK` para limpiar la sesión:

```sql
BEGIN;
SET search_path TO biblioteca, public;
INSERT INTO persona (id_persona, nombres, apellido_paterno, correo, tipo_persona)
VALUES (9999, 'Prueba', 'Incompleta', 'subtipo9999@escuela.test', 'ESTUDIANTE');
COMMIT;
-- ERROR esperado, SQLSTATE 23514; no usarlo como dato real exitoso.
```

También puede intentarse insertar un docente para una Persona de tipo ESTUDIANTE, lo cual debe fallar al cerrar la transacción. Haz estas pruebas solamente en una BD nueva de laboratorio.

## 5. Entrega final en Teams

**Tarea 4.1:** subir PDF + enlace real al repositorio + enlace real a video 4.1.  
**Tarea 4.2:** subir PDF + enlace real al repositorio (puede ser el mismo) + enlace real a video 4.2.

Nunca afirmes que el script está verificado en PostgreSQL sin ejecutarlo primero en tu equipo.
