# Diferencias reales entre U3 y U4

- **12 tablas y 11 FK:** conservadas; no se introducen entidades ficticias.
- **42 a 40 columnas:** se elimina `estudiante.tipo_persona = 'ESTUDIANTE'` y `docente.tipo_persona = 'DOCENTE'`.
- **Motivo formal:** una columna constante impone la DF `∅ → tipo_persona`; el conjunto vacío no es superclave para relaciones con varias filas. El atributo constante es redundante y viola 3FN/FNBC.
- **Control de herencia:** `persona.tipo_persona` se almacena una sola vez. Nuevos triggers diferibles validan al COMMIT la especialización total y disjunta: un subtipo existente, del tipo correcto y sin doble clasificación.
- **PK/FK:** ambas tablas hijas mantienen `id_persona` como PK y FK simple a `persona.id_persona`. La columna auxiliar compuesta `UNIQUE (id_persona,tipo_persona)` de `persona` deja de ser necesaria.
- **N:M y multivalorados:** permanecen `libro_autor`, `libro_coleccion`, `persona_telefono`.
- **Atributos derivados:** permanecen en vistas, sin duplicación persistente.
- **Protección histórica:** `prestamo` e `incidencia` conservan `ON DELETE RESTRICT` en relaciones históricas.
- **No es una migración in situ:** el archivo crea un esquema nuevo en una base vacía. No lo ejecute sobre la BD de Unidad 3.

**Estado de validación:** comprobaciones estáticas del SQL y coherencia con U3; se requiere PostgreSQL 14+ para comprobar ejecución, triggers y capturas de evidencia.
