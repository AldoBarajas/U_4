-- INSPECCION NO DESTRUCTIVA; usar despues de la creacion del esquema.
SELECT table_name FROM information_schema.tables
 WHERE table_schema = 'biblioteca' AND table_type = 'BASE TABLE'
 ORDER BY table_name;
SELECT table_name, count(*) AS columnas FROM information_schema.columns
 WHERE table_schema = 'biblioteca' GROUP BY table_name ORDER BY table_name;
SELECT count(*) AS total_tablas FROM information_schema.tables
 WHERE table_schema = 'biblioteca' AND table_type = 'BASE TABLE';
SELECT count(*) AS total_columnas FROM information_schema.columns
 WHERE table_schema = 'biblioteca';
SELECT count(*) AS total_claves_foraneas FROM information_schema.table_constraints
 WHERE table_schema = 'biblioteca' AND constraint_type = 'FOREIGN KEY';
SELECT table_name,column_name,is_nullable,data_type
 FROM information_schema.columns WHERE table_schema='biblioteca'
 AND table_name IN ('estudiante','docente','persona')
 ORDER BY table_name,ordinal_position;
SELECT tgname,relname AS tabla, tgenabled
 FROM pg_trigger JOIN pg_class ON pg_class.oid = tgrelid
 JOIN pg_namespace n ON n.oid = pg_class.relnamespace
 WHERE n.nspname='biblioteca' AND NOT tgisinternal
 ORDER BY relname,tgname;
-- Las dos consultas siguientes requieren haber cargado datos_demostracion.sql:
SELECT p.id_persona,p.tipo_persona,
 EXISTS (SELECT 1 FROM biblioteca.estudiante e WHERE e.id_persona=p.id_persona) AS en_estudiante,
 EXISTS (SELECT 1 FROM biblioteca.docente d WHERE d.id_persona=p.id_persona) AS en_docente
 FROM biblioteca.persona p ORDER BY p.id_persona;
SELECT l.isbn,COUNT(DISTINCT la.id_autor) AS autores,
 COUNT(DISTINCT lc.id_coleccion) AS colecciones
 FROM biblioteca.libro l
 LEFT JOIN biblioteca.libro_autor la ON la.isbn=l.isbn
 LEFT JOIN biblioteca.libro_coleccion lc ON lc.isbn=l.isbn
 GROUP BY l.isbn ORDER BY l.isbn;
