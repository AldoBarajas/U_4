-- PRUEBAS NEGATIVAS AUTOCONTENIDAS. Ejecutar despues de schema y datos demo.
-- Cada operacion incorrecta se revierte automaticamente dentro del bloque DO.
-- Salida esperada: NOTICE OK. No se conservan datos de las pruebas negativas.
SET search_path TO biblioteca, public;
DO $$
BEGIN
    BEGIN
        INSERT INTO persona (id_persona,nombres,apellido_paterno,correo,tipo_persona)
        VALUES (103,'Prueba','Invalida','prueba103@escuela.test','ESTUDIANTE');
        INSERT INTO estudiante (id_persona,matricula,semestre)
        VALUES (103,'INVALIDA',99);
        RAISE EXCEPTION 'FALLO: se acepto un semestre invalido';
    EXCEPTION WHEN check_violation THEN
        RAISE NOTICE 'OK: CHECK semestre impide valor 99';
    END;
    BEGIN
        INSERT INTO ejemplar (id_ejemplar,isbn,codigo_inventario)
        VALUES (9001,'9780000000002','INV-ERROR');
        RAISE EXCEPTION 'FALLO: se acepto FK de libro inexistente';
    EXCEPTION WHEN foreign_key_violation THEN
        RAISE NOTICE 'OK: FK ejemplar-libro impide ISBN inexistente';
    END;
    BEGIN
        INSERT INTO prestamo (id_prestamo,id_persona,id_ejemplar,fecha_salida,fecha_limite)
        VALUES (9002,101,401,DATE '2026-11-08',DATE '2026-11-19');
        RAISE EXCEPTION 'FALLO: se acepto doble prestamo activo';
    EXCEPTION WHEN unique_violation THEN
        RAISE NOTICE 'OK: indice unico parcial impide doble prestamo activo';
    END;
END;
$$;
-- PRUEBA DIFERIBLE MANUAL (en la GUIA): insertar persona sin subtipo, COMMIT
-- debe fallar con SQLSTATE 23514. No se ejecuta aqui porque el error esperado
-- interrumpiria el lote; no se deben inventar capturas.
