-- Ejecutar despues de normalized_schema.sql EN UNA BASE VACIA DE PRUEBA.
BEGIN;
SET search_path TO biblioteca, public;
INSERT INTO persona (id_persona,nombres,apellido_paterno,correo,tipo_persona) VALUES
 (101,'Elena','Lopez','elena.ejemplo@escuela.test','ESTUDIANTE'),
 (102,'Carlos','Ruiz','carlos.ejemplo@escuela.test','DOCENTE');
INSERT INTO estudiante (id_persona,matricula,semestre) VALUES (101,'EST-0001',4);
INSERT INTO docente (id_persona,numero_empleado,departamento) VALUES (102,'DOC-0001','Matematicas');
INSERT INTO persona_telefono (id_persona,telefono) VALUES
 (101,'8661001001'),(101,'8661001002'),(102,'8661001003');
INSERT INTO autor (id_autor,nombre) VALUES (201,'Autora Ejemplo'),(202,'Autor de Prueba');
INSERT INTO coleccion (id_coleccion,nombre) VALUES (301,'Matematicas'),(302,'Ciencia');
INSERT INTO libro (isbn,titulo,anio_publicacion) VALUES
 ('9780306406157','Introduccion al Algebra',2020);
INSERT INTO libro_autor (isbn,id_autor) VALUES
 ('9780306406157',201),('9780306406157',202);
INSERT INTO libro_coleccion (isbn,id_coleccion) VALUES
 ('9780306406157',301),('9780306406157',302);
INSERT INTO ejemplar (id_ejemplar,isbn,codigo_inventario,estado) VALUES
 (401,'9780306406157','INV-0401','DISPONIBLE');
INSERT INTO prestamo (id_prestamo,id_persona,id_ejemplar,fecha_salida,fecha_limite,fecha_devolucion)
 VALUES (501,101,401,DATE '2026-11-01',DATE '2026-11-15',NULL);
INSERT INTO incidencia (id_incidencia,id_prestamo,tipo,fecha,observacion)
 VALUES (601,501,'OTRA',DATE '2026-11-06','Revision administrativa de ejemplo');
COMMIT;
-- El validador total/disjunto y el validador de autoria se ejecutan en COMMIT.
